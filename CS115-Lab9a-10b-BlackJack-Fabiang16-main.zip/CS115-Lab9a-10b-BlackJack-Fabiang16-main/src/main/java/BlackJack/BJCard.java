package BlackJack;

import BlackJackBase.PCard;
import java.awt.Color;

public class BJCard extends PCard {

    public static final int ACE = 1;
    public static final int TWO = 2;
    public static final int THREE = 3;
    public static final int FOUR = 4;
    public static final int FIVE = 5;
    public static final int SIX = 6;
    public static final int SEVEN = 7;
    public static final int EIGHT = 8;
    public static final int NINE = 9;
    public static final int TEN = 10;
    public static final int JACK = 11;
    public static final int KNIGHT = 12;
    public static final int QUEEN = 13;
    public static final int KING = 14;

    public static final int SPADE = 1;
    public static final int HEART = 2;
    public static final int DIAMOND = 3;
    public static final int CLUB = 4;

    private int rank;
    private int suit;
    private boolean hidden;

    public BJCard(int rank, int suit) {
        this.rank = rank;
        this.suit = suit;
        this.hidden = false;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getSuit() {
        return suit;
    }

    public void setSuit(int suit) {
        this.suit = suit;
    }

    @Override
    public void hideCard() {
        hidden = true;
    }

    @Override
    public void showCard() {
        hidden = false;
    }

    @Override
    public boolean isHidden() {
        return hidden;
    }

    @Override
    public String getText() {
        if (hidden) {
            return "??";
        }
        return getRankString() + getSuitSymbol();
    }

    private String getRankString() {
        switch (rank) {
            case ACE: return "A";
            case TWO: return "2";
            case THREE: return "3";
            case FOUR: return "4";
            case FIVE: return "5";
            case SIX: return "6";
            case SEVEN: return "7";
            case EIGHT: return "8";
            case NINE: return "9";
            case TEN: return "10";
            case JACK: return "J";
            case KNIGHT: return "Kn";
            case QUEEN: return "Q";
            case KING: return "K";
            default: return "?";
        }
    }

    private String getSuitSymbol() {
        switch (suit) {
            case SPADE: return "\u2660"; // ♠
            case HEART: return "\u2665"; // ♥
            case DIAMOND: return "\u2666"; // ♦
            case CLUB: return "\u2663"; // ♣
            default: return "?";
        }
    }

    @Override
    public Color getFontColor() {
        if (suit == HEART || suit == DIAMOND) {
            return Color.RED;
        } else {
            return Color.BLACK;
        }
    }

    @Override
    public Color getBorderColor() {
        return Color.BLACK;
    }

    @Override
    public Color getFaceColor() {
        return Color.WHITE;
    }

    @Override
    public Color getBackColor() {
        return Color.LIGHT_GRAY;
    }
//
    @Override
    public Color getStripeColor() {
        return Color.GRAY;
    }
}

