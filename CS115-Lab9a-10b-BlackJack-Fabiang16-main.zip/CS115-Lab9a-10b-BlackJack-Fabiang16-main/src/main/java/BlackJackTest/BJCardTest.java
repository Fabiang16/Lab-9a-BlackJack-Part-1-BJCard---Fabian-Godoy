package BlackJackTest;

import BlackJack.BJCard;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BJCardTest {

    @Test
    void testInitialValues() {
        BJCard card = new BJCard(BJCard.QUEEN, BJCard.HEART);
        assertEquals(BJCard.QUEEN, card.getRank());
        assertEquals(BJCard.HEART, card.getSuit());
        assertFalse(card.isHidden());
    }

    @Test
    void testHideAndShowCard() {
        BJCard card = new BJCard(BJCard.ACE, BJCard.SPADE);
        card.hideCard();
        assertTrue(card.isHidden());
        card.showCard();
        assertFalse(card.isHidden());
    }

    @Test
    void testGetTextHidden() {
        BJCard card = new BJCard(BJCard.ACE, BJCard.SPADE);
        card.hideCard();
        assertEquals("??", card.getText());
    }

    @Test
    void testGetTextVisible() {
        BJCard card = new BJCard(BJCard.KING, BJCard.CLUB);
        assertEquals("K\u2663", card.getText());
    }

    @Test
    void testSetters() {
        BJCard card = new BJCard(BJCard.TWO, BJCard.DIAMOND);
        card.setRank(BJCard.KNIGHT);
        card.setSuit(BJCard.HEART);
        assertEquals(BJCard.KNIGHT, card.getRank());
        assertEquals(BJCard.HEART, card.getSuit());
    }
}
