package BlackJackTest;

import BlackJack.BJCard;

public class PlayBlackJack {
    public static void main(String[] args) {
        // Ace of Spade
        BJCard aceOfSpade = new BJCard(BJCard.ACE, BJCard.SPADE);
        CardTest.run(aceOfSpade);
        System.out.println();

        // Six of Heart
        BJCard sixOfHeart = new BJCard(BJCard.SIX, BJCard.HEART);
        CardTest.run(sixOfHeart);
        System.out.println();

        // Jack of Spade
        BJCard jackOfSpade = new BJCard(BJCard.JACK, BJCard.SPADE);
        CardTest.run(jackOfSpade);
        System.out.println();

        // Knight of Heart
        BJCard knightOfHeart = new BJCard(BJCard.KNIGHT, BJCard.HEART);
        CardTest.run(knightOfHeart);
        System.out.println();

        // Queen of Diamond
        BJCard queenOfDiamond = new BJCard(BJCard.QUEEN, BJCard.DIAMOND);
        CardTest.run(queenOfDiamond);
        System.out.println();

        // King of Club
        BJCard kingOfClub = new BJCard(BJCard.KING, BJCard.CLUB);
        CardTest.run(kingOfClub);
        System.out.println();
    }
}
